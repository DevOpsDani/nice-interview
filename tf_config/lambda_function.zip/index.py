import boto3
s3 = boto3.client('s3',region_name='us-east-1')

# def parse_me(file_content):
#     with open(input_file, 'r') as parse_file:
#         data=parse_file.read()

#     data=data.replace("00", " ")
#     data=''.join([i for i in data if not i.isdigit()])
#     return data

# try:
#     response = s3.get_object(Bucket='daniel-interview-s3-nice-tf-backend', Key='parse_me.txt')
#     file_content = response['Body'].read().decode('utf-8')

# except Exception as error:
#     print(f"ERROR: {error}")

def lambda_handler(event, context):
    test='19I004a4m00p34a21s789s232i1ona23te00a67bo2ut00D21e3v23Op31s00j87o253b!'
    print(test)
