import boto3
import json

def parse_content(data):
    data=data.replace("00", " ")
    data=''.join([i for i in data if not i.isdigit()])
    return data

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read().decode('utf-8')
        conv_content=parse_content(content)
        return {
            'statusCode': 200,
            'body': json.dumps(conv_content)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps('Error reading file:', str(e))
        }

