import boto3
import json

s3_client = boto3.client('s3')

def parse_content(data):
    data=data.replace("00", " ")
    data=''.join([i for i in data if not i.isdigit()])
    return data

def invoke_notification_lambda(payload):
    target_lambda_name = 'daniel-interview-lambda-nice-devops-interview-notifications'

    try:
        response = lambda_client.invoke(
            FunctionName=target_lambda_name,
            InvocationType='Event',  
            Payload=json.dumps(payload)
        )
        return True

    except Exception as e:
        print(f"Error invoking Lambda function: {e}")
        return False


def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read().decode('utf-8')
        invoke_notification_lambda(conv_content)
        return {
            'statusCode': 200,
            'body': json.dumps('File processed and another Lambda invoked successfully!')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error reading file: {str(e)}')
        }
